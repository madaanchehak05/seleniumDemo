package Utilities;

public class FileFolderUtils {
    public static String excelTestDataPath = System.getProperty("user.dir")+"/src/test/resources/TestData.xlsx";
}
