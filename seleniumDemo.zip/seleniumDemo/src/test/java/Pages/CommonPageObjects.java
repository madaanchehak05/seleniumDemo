package Pages;

import org.openqa.selenium.By;

public class CommonPageObjects {

    public static By commonButton(String text){
        return By.xpath("//button[text()='"+text+"']");
    }


}
