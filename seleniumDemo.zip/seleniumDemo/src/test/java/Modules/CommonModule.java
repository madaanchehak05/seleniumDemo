package Modules;

import Pages.CommonPageObjects;
import Pages.LoginPageObjects;
import Utilities.DriverUtils;

public class CommonModule extends DriverUtils {

    public static void commonClick(String text) {
        boolean flag = false;
        try {
            click(CommonPageObjects.commonButton(text), "Login");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void navigateToCategories(){

    }

}
