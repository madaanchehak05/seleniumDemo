package stepDefinitions;

import io.cucumber.java.en.And;

public class CommonStep {
    @And("Navigate to Categories")
    public void navigateToCategories() {

    }
}
